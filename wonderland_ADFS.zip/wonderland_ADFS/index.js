const fs = require("fs");
const path = require("path");
const thirdParty = require('./third_party').getInstance();
const config = require('./config.json');
const options = config.isTest ? config.testOptions : config.realOptions;
const { reqHandler, resHandler } = require(__dir + "/core/utils");
const passport = require('passport');
const SamlStrategy = require('passport-saml').Strategy;
const { loginUrl, logoffUrl, entity_id, acsUrl, certName } = options;
const certPath = path.join(__dir + `/core/middlewares/singleLogin/wonderland/${certName}`);
const cert = fs.readFileSync(certPath, "utf8");

// Azure AD SAML [配置]
const samlStrategy = new SamlStrategy({
  entryPoint: loginUrl,
  issuer: entity_id,
  callbackUrl: acsUrl,
  cert: cert,
}, (profile, done) => {
  return done(null, profile)
})

// 注册 SAML 策略
passport.use(samlStrategy);

// 序列化 & 反序列化用户
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((user, done) => done(null, user));

module.exports = async (req, res, next) => {
  if (req.url === "/slogin") {
    // 触发 SAML 认证
    passport.authenticate("saml")(req, res, next);
  } else if (req.url.includes("/auth/callback")) {
    const { protocol, host } = req;
    const data = reqHandler.httpPostData(req, res);
    // 处理 SAML 回调
    passport.authenticate("saml", async (err, user, info) => {
      if (err || !user) {
        return res.status(401).send("SAML 认证失败");
      }
      const samlResponse = data.SAMLResponse;
      // 解析 SAML 令牌, 校验 user 登陆
      let resData = await thirdParty.authCallback(samlResponse, protocol, host);
      if (resData.ret === 0) {
        const { sessionID, userName } = resData.data;
        const redirectURL = `${protocol}://${host}:8699/?session=${sessionID}&username=${userName}`;
        res.redirect(302, redirectURL);
      } else {
        let errMsg = resData.errMsg;
        res.status(errMsg.status).send(errMsg.msg);
      }
    })(req, res, next);
  } else {
    next();
  }
};
