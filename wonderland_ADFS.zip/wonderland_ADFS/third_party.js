const config = require('./config.json');
const options = config.isTest ? config.testOptions : config.realOptions;
const xml2js = require('xml2js');
const { wosLogin } = require('../util');

class ThirdParty {
  constructor() {
      this.protocol = null;
      this.host = null;
      this.password = options.password || null;
  }

  async authCallback(samlRes, protocol, host) {
      this.protocol = protocol;
      this.host = host;
      let resData = {
          ret: 0,
          errMsg: {
            status: null,
            msg: null,
          },
          data: {
              sessionID: null,
              userName: null,
              lastName: null,
          },
      };

      if (!samlRes) {
        let errMessage = "无效的 SAML 响应";
        logger.log("error", errMessage);
        resData.ret = -1;
        resData.errMsg = { status: 400, msg: errMessage};
        return resData;
      }

      try {
        const decodeRes = Buffer.from(samlRes, "base64").toString("utf-8");
        let xmlRes = await this.parseStringSync(decodeRes, resData);
        if (xmlRes.ret) return xmlRes;
        const userName = xmlRes.data.userName;

        // 验证用户登陆
        let res = await wosLogin(this.protocol, this.host, userName, this.password);
  
        logger.log("debug", `loginsvcuserbyrole info lastName: ${xmlRes.data.lastName}, userName: ${xmlRes.data.userName} ${JSON.stringify(res)}`);
  
        if (res.ret !== 0 || !res.data || !res.data.data || res.data.data.ret !== 0) {
            let errMessage = "WOS 用户登陆校验失败";
            logger.log("error", errMessage);
            resData.ret = -4;
            resData.errMsg = { status: 400, msg: errMessage};
            return resData;
        }
        const { sessionID } = res.data.data;
        resData.data.sessionID = sessionID;
        logger.log("debug", `loginresponse sessionid ${sessionID}`);
        return resData;
      } catch (error) {
        let errMessage = "SAML 处理错误/ WOS 用户登陆校验失败";
        logger.log("error", errMessage);
        resData.ret = 1000;
        resData.errMsg = { status: 500, msg: errMessage};
        return resData;
      }
  }

parseStringSync(xml, resData) {
    return new Promise((resolve, reject) => {
        xml2js.parseString(xml, async (err, result) => {
            if (err) {
                let errMessage = "SAML 解析失败";
                logger.log("error", errMessage);
                resData.ret = -2;
                resData.errMsg = { status: 500, msg: errMessage};
                resolve(resData);
            }
            console.log("ADFS XML RESULT:",JSON.stringify(result));
            // 提取用户信息
            const assertion = result["samlp:Response"]["Assertion"][0];
            const attributes = assertion["AttributeStatement"][0]["Attribute"];
            let givenName = "";
            let surname = "";

            attributes.forEach(attr => {
                if (attr.$.Name === "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name") givenName = attr["AttributeValue"][0];
                if (attr.$.Name === "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress") surname = attr["AttributeValue"][0];
            });
            
            if (!givenName || !surname) {
                let errMessage = "SAML 令牌缺少用户标识信息";
                logger.log("error", errMessage);
                resData.ret = -3;
                resData.errMsg = { status: 400, msg: errMessage};
                resolve(resData);
            }
            resData.data.lastName = givenName;
            resData.data.userName = surname;
            resolve(resData);
        })
    })    
  }
  /**
   * @description 单例模式
   * @returns     instance
   */
  static getInstance() {
      if (!ThirdParty.instance) {
          ThirdParty.instance = new ThirdParty();
      }
      return ThirdParty.instance;
  }
}

module.exports = ThirdParty;
